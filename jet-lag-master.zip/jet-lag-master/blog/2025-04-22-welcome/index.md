---
slug: welcome
title: Welcome
authors: [collinj]
tags: [jetlag]
---

Welcome to the hidden Jet Lag: The Game blog!
