---
sidebar_position: 1
---
# Experimental Game Designs

In previous sections we've detailed the rules for conventional configurations of *Hide and Seek*. We have, however, considered some alternate versions of the game, and we thought we'd detail those here in case you'd like to try them–or use them as a jumping off point for your own game mode!
