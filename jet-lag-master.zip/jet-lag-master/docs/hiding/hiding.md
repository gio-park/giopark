---
sidebar_position: 1
---
# Hiding

As the hider, it is your job to stay hidden for as long as possible; stay hidden for longer than anyone else, and the game is yours. At the start of each run, you'll be given a certain amount of time to choose–and travel to–a hiding zone somewhere on your map. While the seekers close in, you'll have to juggle the tasks of answering questions, scoping out a perfect final hiding spot, and assembling the perfect hand using cards from the hider deck.
