---
sidebar_position: 3
---

# Creating Teams

Generally, **we do not recommend playing with more than four players**. If you do want to play with more than four players, we would suggest grouping some players into teams. Those teams (of two or more) could collectively act as a single player, all hiding together when it is their turn to hide. There may be some unforseen awkwardness with how to answer certain questions that are intended for a single player, which will need to be resolved on a case-by-case basis. Teams are also recommended when playing with younger players, or in any context where a hider would feel unsafe or uncomfortable being alone for an extended period of time.
