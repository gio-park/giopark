---
sidebar_position: 4
---
# Setting Your Map

After you have chosen a game size and assembled your players, you'll need to set up your game map. This involves choosing a **transit system** and establishing **map borders**. (For more information on setting up your map, visit [Setting Up Your Map](../setting_up_your_map))
