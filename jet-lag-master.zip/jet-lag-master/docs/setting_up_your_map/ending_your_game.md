---
sidebar_position: 5
---

# Ending Your Game

Generally, _Hide and Seek_ ends once the predetermined number of rounds is complete. If, however, you're playing with a hard out _(i.e. you have a flight home or, you know, need to go to school/work)_ we would also recommend setting an end-of-game timer. In that case, the game would end whenever you reach the predetermined number of rounds or the timer runs out, whichever comes first.
