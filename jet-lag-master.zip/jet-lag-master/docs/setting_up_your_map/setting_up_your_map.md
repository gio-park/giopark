---
sidebar_position: 1
---
# Setting Up Your Map

Our goal, when designing _Hide and Seek_, was to make a game that can be played almost anywhere in the world. In order to accomplish this, we established a few simple steps that should generate a viable game map wherever you choose to play. Here's how to set the parameters of your game:
